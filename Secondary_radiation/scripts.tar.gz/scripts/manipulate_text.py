#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 17:01:04 2021

@author: mitchellweikert
"""
from os import listdir

def gen_fileinfo(out_index, mx=None, channel='bb_bar', sigma_v=None, Rmax=None, 
                 DA=None, D0=None, nu_range=None, rho_range=None, B_model=None, 
                 rho_star_model=None, DM_model=None, f_star_params=None, nr=None, 
                 nE = None, nrho=None, nnu=None):
    output_types = ['electron_spectrum', 'equillibrium_distribution', 'synchrotron_emission', 'inverse_compton_emission', 'photon_spectrum']
    content = output_types[out_index] + '\n\n' + \
    'Dark Matter Particle Mass: ' + str(mx) + 'GeV' + '\n' + \
    'Annihilation Channel: ' + str(channel) + '\n'
    if (not out_index == 0) and (not out_index==4):
        content = content + 'Thermally Averaged Cross-section: ' + str(sigma_v) + 'cm^3/s' + '\n' + \
        'Diffusion Radius: ' + str(Rmax) + 'kpc' + '\n' + \
        'Angular Distance: ' + str(DA) + 'kpc' + '\n'+ \
        'Diffusion Coefficient Normalization: ' + str(D0) + 'cm^2/s' + '\n'
        for model in B_model:
            content = content + 'Magnetic Field Model: ' + 'model type- '
            if model[0] == 'exp':
                content = content + 'Exponential; '
                content = content + 'B0- ' + str(model[1]) + 'uG; ' + 'Scale Radius- ' + str(model[2]) + 'kpc; \n'
            else:
                print('Magnetic Field Model Unidentified')
        for model in rho_star_model:
            content = content + 'Stellar Radiation Energy Density Model: ' + 'model type- '
            if model[0] == 'exp':
                content = content + 'Exponential; '
                content = content + 'rho0- ' + str(model[1]) + 'eV/cm^3; ' + 'Scale Radius- ' + str(model[2]) + 'kpc; \n'
            else:
                print('Stellar Radiation Model Unidentified')
        for model in DM_model:
            content = content + 'Dark matter Density Model: ' + 'model type- '
            if model[0] == 'exp':
                content = content + 'Exponential; '
                content = content + 'rho0- ' + str(model[1]) + 'GeV/cm^3; ' + 'Scale Radius- ' + str(model[2]) + 'kpc; \n'
            elif model[0] == 'nfw':
                content = content + 'NFW; '
                content = content + 'rho0- ' + str(model[1]) + 'GeV/cm^3; ' + 'gamma- '+ str(model[2]) + '; Scale Radius- ' + str(model[3]) + 'kpc; \n'
            else:
                print('Dark Matter Density Model Unidentified')
        content = content + 'Number of r steps: ' + str(nr) + '\n'
        content = content + 'Number of E steps: ' + str(nE) + '\n'
        if not (out_index == 1):
            content = content + 'Stellar Emmission Distribution Parameters: '  + 'average temperature- ' + str(f_star_params[0]) + 'K; ' + 'standard deviation of temperature- ' + str(f_star_params[1]) + 'K; \n'
            content = content + 'Number of rho steps: ' + str(nrho) + '\n'
            content = content + 'Number of nu steps: ' + str(nnu) + '\n'
            content = content + 'rho_range: ' + str(rho_range) + ' (kpc)' + '\n'
            content = content + 'nu_range: ' + str(nu_range) + ' (Hz)' + '\n'
    return content

def check_txt_files(file_info, path, temp=False):
    output_type = file_info.split('\n')[0]
    files = [f for f in listdir(path+output_type)]
    code = None
    output_name=None
    codes=[]
    for f in files:
        f_type = f.split('.')[-1]
        if f_type == 'txt' and not f[0]=='.':
            codes.append(f.split('_')[0])
            txt_file = open(path+output_type+ '/' + f, 'r')
            txt_file_read = txt_file.read()
            if txt_file_read == file_info:
                code = f.split('_')[0]
                break
    if code==None:
        exists = False
        check_code=True
        codes_int = [int(code) for code in codes]
        if not codes_int==[]:
            code = str(max(codes_int)+1).zfill(4)
        else:
            code = '0001'    

        file_info_name = path + output_type + '/' + code + '_' + output_type + '_info.txt'
        #create and save file info txt file
        f = open(file_info_name, "w")
        f.write(file_info)
        f.close()
        message = 'The ' + output_type + ' output does not exist. The newly generated file info .txt file, ' + file_info_name + ', was saved. The new output .npy file will be called: '
    else:
        exists = True
        file_info_name = path+output_type + '/' + code + '_' + output_type + '_info.txt'
        message = 'The ' + output_type + ' output does exist. The file info .txt file is located at: '  + file_info_name + '. The .npy output file is located at: '
    if temp:
        output_name = path + output_type + '/' + code + '_temporary_' + output_type + '.npy'
    else:
        output_name = path + output_type + '/' + code + '_' + output_type + '.npy'
    message = message + output_name
    #print(message)
    return output_name, file_info_name, exists, code

if __name__=='__main__':
    file_info = gen_fileinfo(2, mx=50, channel='bb_bar', sigma_v=2.2e-26, Rmax=50, DA=780, D0=3e28, nu_range=[1e5, 1e22],
                rho_range=[100, 45000], B_model=[['exp', '10', '1.5'], ['exp', '8', '20']], rho_star_model=[['exp', '8', '4.3']], DM_model=[['nfw', '0.43', '1.25', '16.5']], f_star_params=[5500, 1000], nr=800, nE = 400, nrho=20, nnu=20)
    print(file_info)
    output_name, file_info_name, exists = check_txt_files(file_info)
    print('exists: ', exists)
